require 'test_helper'

class ListNameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
