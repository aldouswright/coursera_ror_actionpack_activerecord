class ListName < ActiveRecord::Base
end
